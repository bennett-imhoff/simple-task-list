import { Task } from "./Task"

export const TASKS: Task[] = [
    {
        id: 1, 
        text: "Terminar primer modulo de Angular",
        day: "Agosto 5 a las 12:00",
        reminder: true
    },
    {
        id: 2, 
        text: "Aprender a crear una API en Spring Boot",
        day: "Agosto 5 a las 16:00",
        reminder: true
    },
    {
        id: 3, 
        text: "Hacer las compras",
        day: "Agosto 6 a las 9:00",
        reminder: false
    },
    {
        id: 4, 
        text: "Investigar sobre Bootstrap",
        day: "Agosto 6 a las 19:00",
        reminder: false
    }
]